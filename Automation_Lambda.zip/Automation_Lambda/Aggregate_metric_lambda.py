def lambda_handler(event, context):
    """
    event = list of MAP state outputs
    Each item expected as:
    {
      "metrics": {
        "<resource_id>": {...}
      }
    }
    """

    final_metrics = {}

    # Defensive: event must be a list
    if not isinstance(event, list):
        print("[WARN] Event is not a list")
        return {"metrics": {}}

    for idx, batch in enumerate(event):
        if not isinstance(batch, dict):
            print(f"[WARN] Skipping non-dict batch at index {idx}")
            continue

        batch_metrics = batch.get("metrics")

        if not isinstance(batch_metrics, dict) or not batch_metrics:
            print(f"[WARN] No metrics found in batch {idx}")
            continue

        for resource_id, data in batch_metrics.items():
            if not resource_id:
                continue

            # Last write wins (expected in Map reduce pattern)
            final_metrics[resource_id] = data

    return {
        "metrics": final_metrics
    }
