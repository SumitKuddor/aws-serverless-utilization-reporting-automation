import boto3
import json
from datetime import datetime, timezone, timedelta

# AWS Clients
ec2_client = boto3.client("ec2")
s3_client = boto3.client("s3")

BUCKET_NAME = "aws-utilization-reports-prod1"

# IST Timezone
IST = timezone(timedelta(hours=5, minutes=30))

def lambda_handler(event, context):
    # Today's date in IST
    today = datetime.now(IST).strftime("%Y-%m-%d")
    EC2_FILE_KEY = f"output/{today}/ec2_inventory.json"

    paginator = ec2_client.get_paginator("describe_instances")
    instances = []

    for page in paginator.paginate():
        for reservation in page.get("Reservations", []):
            for inst in reservation.get("Instances", []):

                instance_id = inst.get("InstanceId", "")
                state = inst.get("State", {}).get("Name", "")
                private_ip = inst.get("PrivateIpAddress", "")
                platform = inst.get("Platform", "linux")
                instance_type = inst.get("InstanceType", "")

                # Tags
                name = ""
                environment = ""
                for tag in inst.get("Tags", []):
                    if tag.get("Key") == "Name":
                        name = tag.get("Value", "")
                    elif tag.get("Key") in ("Environment", "Env"):
                        environment = tag.get("Value", "")

                instances.append({
                    "instance_id": instance_id,
                    "name": name,
                    "instance_type": instance_type,   # ✅ IMPORTANT
                    "state": state,
                    "platform": platform,
                    "private_ip": private_ip,
                    "environment": environment
                })

    # Final JSON structure
    data = {
        "total_ec2": len(instances),
        "ec2_instances": instances,
        "generated_at": datetime.now(IST).isoformat(),
        "timezone": "IST"
    }

    # Upload to S3
    s3_client.put_object(
        Bucket=BUCKET_NAME,
        Key=EC2_FILE_KEY,
        Body=json.dumps(data, indent=2),
        ContentType="application/json"
    )

    return {
        "status": "success",
        "s3_path": f"s3://{BUCKET_NAME}/{EC2_FILE_KEY}",
        "total_ec2": len(instances)
    }
