import boto3
import json
import datetime
import os
import logging
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from docx.shared import Pt
from docx.shared import Inches, Pt, RGBColor

logger = logging.getLogger()
logger.setLevel(logging.INFO)

session = boto3.Session(region_name="ap-south-1")
cloudwatch = session.client("cloudwatch")
s3_client = session.client("s3")

BUCKET_NAME = "aws-utilization-reports-prod1"
DAYS_RANGE = 7
TMP_DIR = "/tmp"


class AWSReportGenerator:
    def __init__(self):
        self.today = datetime.datetime.utcnow().strftime("%Y-%m-%d")

    # ---------------- Create daily folders ----------------
    def create_daily_folders(self):
        for p in [f"images/{self.today}/", f"reports/{self.today}/"]:
            s3_client.put_object(Bucket=BUCKET_NAME, Key=p, Body=b"")

    # ---------------- Fetch EC2 from S3 Inventory ----------------
    def get_ec2_instances(self):
        key = f"output/{self.today}/ec2_inventory.json"
        try:
            obj = s3_client.get_object(Bucket=BUCKET_NAME, Key=key)
            data = json.loads(obj["Body"].read())
            return data.get("ec2_instances", [])
        except s3_client.exceptions.NoSuchKey:
            logger.warning(f"EC2 inventory not found: {key}")
            return []

    # ---------------- Fetch RDS from S3 Inventory ----------------
    def get_rds_instances(self):
        key = f"output/{self.today}/rds_inventory.json"
        try:
            obj = s3_client.get_object(Bucket=BUCKET_NAME, Key=key)
            data = json.loads(obj["Body"].read())
            return data.get("rds_instances", [])
        except s3_client.exceptions.NoSuchKey:
            logger.warning(f"RDS inventory not found: {key}")
            return []

    # ---------------- CloudWatch Metric Image ----------------
    def get_metric_image(self, namespace, metric, dimensions, title):
        widget = {
            "metrics": [[namespace, metric] + sum([[d["Name"], d["Value"]] for d in dimensions], [])],
            "view": "timeSeries",
            "stat": "Average",
            "period": 3600,
            "title": title,
            "region": "ap-south-1",
            "start": f"-PT{DAYS_RANGE*24}H",
            "end": "P0D",
            "width": 1200,
            "height": 350,
            "annotations": {
                "horizontal": [
                    {
                        "color": "#000000",
                        "label": "",
                        "value": 0,
                        "fill": "below",
                        "visible": False
                    }
                ]
            },
            "yAxis": {
                "left": {
                    "min": 0,
                    "label": "",
                    "showUnits": False
                }
            },
            "legend": {
                "position": "bottom"
            },
            "period": 300,
            "stacked": False,
            "setPeriodToTimeRange": False,
            "stat": "Average",
            "region": "ap-south-1"
        }
        return cloudwatch.get_metric_widget_image(
            MetricWidget=json.dumps(widget),
            OutputFormat="png"
        )["MetricWidgetImage"]

    # ---------------- CloudWatch Metric Average ----------------
    def avg_metric(self, namespace, metric, dimensions):
        end = datetime.datetime.utcnow()
        start = end - datetime.timedelta(days=DAYS_RANGE)

        resp = cloudwatch.get_metric_statistics(
            Namespace=namespace,
            MetricName=metric,
            Dimensions=dimensions,
            StartTime=start,
            EndTime=end,
            Period=3600,
            Statistics=["Average"]
        )
        d = resp.get("Datapoints", [])
        if not d:
            return "N/A"
        return round(sum(x["Average"] for x in d) / len(d), 2)

         # ---------------- Generate Word Report ----------------
    def generate_word(self, ec2, rds):
        doc = Document()
        
        # ============== SET A4 PAGE SIZE ==============
        section = doc.sections[0]
        section.page_height = Inches(11.69)  # A4 height
        section.page_width = Inches(8.27)    # A4 width
        
        # Set margins for A4
        section.top_margin = Inches(0.5)
        section.bottom_margin = Inches(0.5)
        section.left_margin = Inches(0.5)
        section.right_margin = Inches(0.5)
        
        # ============== FIRST PAGE: COVER PAGE & TOC ==============
        # Add branding header
        header_para = doc.add_paragraph()
        header_run = header_para.add_run("FORBES MARSHALL")
        header_run.bold = True
        header_run.font.size = Pt(24)
        header_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        
        # Add main title
        title_para = doc.add_paragraph()
        title_run = title_para.add_run("\nAWS Infrastructure Utilization Weekly Report\n")
        title_run.bold = True
        title_run.font.size = Pt(18)
        title_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        
        # Add date range
        end_date = datetime.datetime.utcnow()
        start_date = end_date - datetime.timedelta(days=DAYS_RANGE-1)
        
        date_range_para = doc.add_paragraph()
        date_range_run = date_range_para.add_run(
            f"Report Period: {start_date.strftime('%d/%m/%Y')} to {end_date.strftime('%d/%m/%Y')}"
        )
        date_range_run.bold = True
        date_range_run.font.size = Pt(12)
        date_range_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        
        # Add decorative line
        line_para = doc.add_paragraph()
        line_run = line_para.add_run("─" * 50)
        line_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        
        # Add executive summary
        doc.add_paragraph()
        summary_heading = doc.add_paragraph()
        summary_heading_run = summary_heading.add_run("EXECUTIVE SUMMARY")
        summary_heading_run.bold = True
        summary_heading_run.font.size = Pt(14)
        
        summary_content = doc.add_paragraph()
        summary_content_run = summary_content.add_run(
            f"This report analyzes AWS resource utilization from {start_date.strftime('%d/%m/%Y')} to {end_date.strftime('%d/%m/%Y')}. "
            "Includes performance metrics for EC2 instances and RDS databases."
        )
        summary_content_run.font.size = Pt(11)
        
        # Add statistics
        doc.add_paragraph()
        stats_heading = doc.add_paragraph()
        stats_heading_run = stats_heading.add_run("REPORT STATISTICS")
        stats_heading_run.bold = True
        stats_heading_run.font.size = Pt(14)
        
        # Calculate statistics
        running_ec2 = len([i for i in ec2 if i.get("state") == "running"])
        available_rds = len([db for db in rds if db.get("status") == "available"])
        
        stats_table = doc.add_table(rows=5, cols=2)
        stats_table.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        stats_table.style = 'Table Grid'  # Add border to table
        
        # Fill statistics table
        stats_data = [
            ["Total EC2 Instances:", str(len(ec2))],
            ["Running EC2 Instances:", str(running_ec2)],
            ["Stopped EC2 Instances:", str(len(ec2) - running_ec2)],
            ["Total RDS Databases:", str(len(rds))],
            ["Available RDS Databases:", str(available_rds)]
        ]
        
        for row_idx, row_data in enumerate(stats_data):
            row_cells = stats_table.rows[row_idx].cells
            row_cells[0].text = row_data[0]
            row_cells[1].text = row_data[1]
            row_cells[0].paragraphs[0].runs[0].bold = True
            row_cells[0].paragraphs[0].runs[0].font.size = Pt(10)
            row_cells[1].paragraphs[0].runs[0].font.size = Pt(10)
        
        # Add TABLE OF CONTENTS
        doc.add_paragraph()
        toc_heading = doc.add_paragraph()
        toc_heading_run = toc_heading.add_run("TABLE OF CONTENTS")
        toc_heading_run.bold = True
        toc_heading_run.font.size = Pt(14)
        
        toc_content = doc.add_paragraph()
        toc_content.add_run("1. Executive Summary\n")
        toc_content.add_run("2. EC2 Instances Performance Analysis\n")
        toc_content.add_run("3. RDS Databases Performance Analysis")
        
        # Add footer
        doc.add_paragraph("\n\n")
        
        footer_para = doc.add_paragraph()
        footer_run = footer_para.add_run("Automation done by: Monitoring Team")
        footer_run.italic = True
        footer_run.font.size = Pt(9)
        footer_para.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
        
        doc.add_paragraph("Confidential - For Internal Use Only").alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        
        # Add page break
        doc.add_page_break()
        
        # ============== EC2 SECTION ==============
        section_header = doc.add_paragraph()
        section_run = section_header.add_run("2. EC2 INSTANCES PERFORMANCE ANALYSIS")
        section_run.bold = True
        section_run.font.size = Pt(16)
        section_header.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        
        if not ec2:
            doc.add_paragraph("No EC2 instances found in the inventory.").italic = True
        else:
            for idx, i in enumerate(ec2, 1):
                name_display = i.get("name") or i.get("instance_id")
                
                # Instance header
                instance_header = doc.add_paragraph()
                instance_run = instance_header.add_run(f"2.{idx} {name_display}")
                instance_run.bold = True
                instance_run.font.size = Pt(13)
                
                # Instance details table
                details_table = doc.add_table(rows=4, cols=2)
                details_table.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
                details_table.style = 'Table Grid'  # Add border to details table
                
                details_data = [
                    ["Instance ID:", i['instance_id']],
                    ["State:", i['state']],
                    ["Platform:", i.get('platform', 'N/A')],
                    ["Instance Type:", i.get('instance_type') or i.get('InstanceType') or i.get('type') or 'N/A']
                ]
                
                for row_idx, row_data in enumerate(details_data):
                    row_cells = details_table.rows[row_idx].cells
                    row_cells[0].text = row_data[0]
                    row_cells[1].text = row_data[1]
                    row_cells[0].paragraphs[0].runs[0].bold = True
                    row_cells[0].paragraphs[0].runs[0].font.size = Pt(10)
                    row_cells[1].paragraphs[0].runs[0].font.size = Pt(10)
                
                doc.add_paragraph()
                
                # Images for running instances
                if i["state"] == "running":
                    dims = [{"Name": "InstanceId", "Value": i["instance_id"]}]
                    metrics = [
                        ("AWS/EC2", "CPUUtilization", dims, "CPU Utilization (%)"),
                        ("CWAgent", "mem_used_percent", dims, "Memory Utilization (%)"),
                        ("CWAgent", "disk_used_percent", dims + [{"Name": "path", "Value": "/"}], "Disk Utilization (%)")
                    ]
                    
                    for metric_idx, (ns, m, d, title) in enumerate(metrics, 1):
                        # Get and save image
                        img = self.get_metric_image(ns, m, d, title)
                        name_img = f"{i['instance_id']}_{m}.png"
                        path = f"{TMP_DIR}/{name_img}"
                        with open(path, "wb") as f:
                            f.write(img)
                        s3_client.put_object(
                            Bucket=BUCKET_NAME,
                            Key=f"images/{self.today}/{name_img}",
                            Body=img,
                            ContentType="image/png"
                        )
                        
                        # Add metric header
                        metric_header = doc.add_paragraph()
                        metric_run = metric_header.add_run(f"{title}")
                        metric_run.bold = True
                        metric_run.font.size = Pt(11)
                        metric_header.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        
                        # Create table for image with border
                        img_table = doc.add_table(rows=1, cols=1)
                        img_table.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        img_table.autofit = False
                        img_table.width = Inches(7.0)
                        img_table.style = 'Table Grid'  # Add border around image
                        
                        # Get cell and add image
                        cell = img_table.cell(0, 0)
                        paragraph = cell.paragraphs[0]
                        paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        run = paragraph.add_run()
                        
                        # Add image
                        image_width = Inches(6.5)
                        run.add_picture(path, width=image_width)
                        
                        # Add spacing after image
                        if metric_idx < len(metrics):
                            doc.add_paragraph()
                        
                else:
                    doc.add_paragraph("\nStatus: Instance is not running. No performance metrics available.").italic = True
                
                # Page break between instances
                if idx < len(ec2):
                    doc.add_page_break()
        
        # ============== RDS SECTION ==============
        doc.add_page_break()
        section_header = doc.add_paragraph()
        section_run = section_header.add_run("3. RDS DATABASES PERFORMANCE ANALYSIS")
        section_run.bold = True
        section_run.font.size = Pt(16)
        section_header.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        
        if not rds:
            doc.add_paragraph("No RDS databases found in the inventory.").italic = True
        else:
            for idx, db in enumerate(rds, 1):
                db_name = db.get("db_identifier") or db.get("DB")
                
                # Database header
                db_header = doc.add_paragraph()
                db_run = db_header.add_run(f"3.{idx} {db_name}")
                db_run.bold = True
                db_run.font.size = Pt(13)
                
                # Database details table
                details_table = doc.add_table(rows=3, cols=2)
                details_table.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
                details_table.style = 'Table Grid'  # Add border to details table
                
                details_data = [
                    ["Database Identifier:", db_name],
                    ["Status:", db['status']],
                    ["Engine:", db.get('engine', 'N/A')]
                ]
                
                for row_idx, row_data in enumerate(details_data):
                    row_cells = details_table.rows[row_idx].cells
                    row_cells[0].text = row_data[0]
                    row_cells[1].text = row_data[1]
                    row_cells[0].paragraphs[0].runs[0].bold = True
                    row_cells[0].paragraphs[0].runs[0].font.size = Pt(10)
                    row_cells[1].paragraphs[0].runs[0].font.size = Pt(10)
                
                doc.add_paragraph()
                
                # Images for available databases
                if db["status"] == "available":
                    dims = [{"Name": "DBInstanceIdentifier", "Value": db_name}]
                    metrics_rds = [
                        ("CPU Utilization (%)", "CPUUtilization"),
                        ("Freeable Memory (MB)", "FreeableMemory"),
                        ("Database Connections", "DatabaseConnections"),
                        ("Read IOPS", "ReadIOPS"),
                        ("Write IOPS", "WriteIOPS")
                    ]
                    
                    # ===== FIRST PAGE: 3 METRICS =====
                    for metric_idx in range(3):
                        title, m = metrics_rds[metric_idx]
                        
                        # Get and save image
                        img = self.get_metric_image("AWS/RDS", m, dims, title)
                        name_img = f"{db_name}_{m}.png"
                        path = f"{TMP_DIR}/{name_img}"
                        with open(path, "wb") as f:
                            f.write(img)
                        s3_client.put_object(
                            Bucket=BUCKET_NAME,
                            Key=f"images/{self.today}/{name_img}",
                            Body=img,
                            ContentType="image/png"
                        )
                        
                        # Add metric header
                        metric_header = doc.add_paragraph()
                        metric_run = metric_header.add_run(f"{title}")
                        metric_run.bold = True
                        metric_run.font.size = Pt(11)
                        metric_header.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        
                        # Create table for image with border
                        img_table = doc.add_table(rows=1, cols=1)
                        img_table.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        img_table.autofit = False
                        img_table.width = Inches(7.0)
                        img_table.style = 'Table Grid'  # Add border around image
                        
                        # Get cell and add image
                        cell = img_table.cell(0, 0)
                        paragraph = cell.paragraphs[0]
                        paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        run = paragraph.add_run()
                        
                        # Add image
                        image_width = Inches(6.5)
                        run.add_picture(path, width=image_width)
                        
                        # Add spacing after image (except after last metric on first page)
                        if metric_idx < 2:
                            doc.add_paragraph()
                    
                    # Add page break after first 3 metrics
                    doc.add_page_break()
                    
                    # ===== SECOND PAGE: 2 METRICS =====
                    # Add "Continued" header for second page
                    db_header_cont = doc.add_paragraph()
                    db_run_cont = db_header_cont.add_run(f"3.{idx} {db_name} (Continued)")
                    db_run_cont.bold = True
                    db_run_cont.font.size = Pt(13)
                    doc.add_paragraph()
                    
                    # Last 2 metrics (index 3 and 4)
                    for metric_idx in range(3, 5):
                        title, m = metrics_rds[metric_idx]
                        
                        # Get and save image
                        img = self.get_metric_image("AWS/RDS", m, dims, title)
                        name_img = f"{db_name}_{m}.png"
                        path = f"{TMP_DIR}/{name_img}"
                        with open(path, "wb") as f:
                            f.write(img)
                        s3_client.put_object(
                            Bucket=BUCKET_NAME,
                            Key=f"images/{self.today}/{name_img}",
                            Body=img,
                            ContentType="image/png"
                        )
                        
                        # Add metric header
                        metric_header = doc.add_paragraph()
                        metric_run = metric_header.add_run(f"{title}")
                        metric_run.bold = True
                        metric_run.font.size = Pt(11)
                        metric_header.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        
                        # Create table for image with border
                        img_table = doc.add_table(rows=1, cols=1)
                        img_table.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        img_table.autofit = False
                        img_table.width = Inches(7.0)
                        img_table.style = 'Table Grid'  # Add border around image
                        
                        # Get cell and add image
                        cell = img_table.cell(0, 0)
                        paragraph = cell.paragraphs[0]
                        paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        run = paragraph.add_run()
                        
                        # Add image
                        image_width = Inches(6.5)
                        run.add_picture(path, width=image_width)
                        
                        # Add spacing after image (except after last metric)
                        if metric_idx < 4:
                            doc.add_paragraph()
                            
                else:
                    doc.add_paragraph("\nStatus: Database is not available. No performance metrics available.").italic = True
                
                # Page break between databases
                if idx < len(rds):
                    doc.add_page_break()
        
        # ============== END OF REPORT ==============
        doc.add_page_break()
        end_para = doc.add_paragraph("\n\n")
        end_run = end_para.add_run("--- End of Report ---")
        end_run.bold = True
        end_run.font.size = Pt(14)
        end_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        
        footer_para = doc.add_paragraph()
        footer_run = footer_para.add_run("Generated by AWS Monitoring Automation | Contact: monitoring@acc.ltd")
        footer_run.italic = True
        footer_run.font.size = Pt(9)
        footer_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        
        path = f"{TMP_DIR}/aws_report_{self.today}.docx"
        doc.save(path)
        return path

    # ---------------- Generate Excel Report ----------------
    def generate_excel(self, ec2, rds):
        wb = Workbook()
        
        # Create professional color scheme
        PRIMARY_COLOR = "366092"  # Dark Blue
        SECONDARY_COLOR = "E6F2FF"  # Light Blue
        LIGHT_GRAY = "F2F2F2"
        WHITE = "FFFFFF"
        
        # Create border style
        thin_border = Border(
            left=Side(style='thin', color='A6A6A6'),
            right=Side(style='thin', color='A6A6A6'),
            top=Side(style='thin', color='A6A6A6'),
            bottom=Side(style='thin', color='A6A6A6')
        )
        
        # Create header style
        header_fill = PatternFill(start_color=PRIMARY_COLOR, end_color=PRIMARY_COLOR, fill_type="solid")
        header_font = Font(bold=True, color=WHITE, size=11)
        title_font = Font(bold=True, size=16, color=PRIMARY_COLOR)
        
        # ============== EC2 Sheet ==============
        ws = wb.active
        ws.title = "EC2 Metrics"
        
        # Add report title
        ws.merge_cells('A1:G1')
        title_cell = ws.cell(row=1, column=1, value="EC2 Utilization Report")
        title_cell.font = title_font
        title_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Add subtitle with date
        ws.merge_cells('A2:G2')
        subtitle_cell = ws.cell(row=2, column=1, value=f"Report Date: {self.today}")
        subtitle_cell.font = Font(size=11, color="808080")
        subtitle_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Add data source info
        ws.merge_cells('A3:G3')
        source_cell = ws.cell(row=3, column=1, value=f"Data Source: CloudWatch (Last {DAYS_RANGE} days)")
        source_cell.font = Font(size=9, italic=True, color="808080")
        source_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Leave one empty row
        ws.row_dimensions[4].height = 5
        
        # Headers start at row 5
        headers = ["Instance ID", "Name", "State", "Platform", "Avg CPU (%)", "Avg Memory (%)", "Avg Disk (%)"]
        
        # Add headers
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=5, column=col_num, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = thin_border
        
        # Set column widths
        column_widths = [18, 20, 12, 12, 12, 14, 12]
        for i, width in enumerate(column_widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = width
        
        # Add EC2 data
        row_num = 6
        for i in ec2:
            dims = [{"Name": "InstanceId", "Value": i["instance_id"]}]
            
            if i["state"] != "running":
                row_data = [
                    i["instance_id"], 
                    i.get("name", ""), 
                    i["state"], 
                    i.get("platform", "N/A"), 
                    "N/A", "N/A", "N/A"
                ]
            else:
                row_data = [
                    i["instance_id"],
                    i.get("name", ""),
                    i["state"],
                    i.get("platform", "N/A"),
                    self.avg_metric("AWS/EC2", "CPUUtilization", dims),
                    self.avg_metric("CWAgent", "mem_used_percent", dims),
                    self.avg_metric("CWAgent", "disk_used_percent", dims + [{"Name": "path", "Value": "/"}])
                ]
            
            # Add row data
            for col_num, value in enumerate(row_data, 1):
                cell = ws.cell(row=row_num, column=col_num, value=value)
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="center", vertical="center")
                
                # Apply alternating row colors
                if row_num % 2 == 0:
                    cell.fill = PatternFill(start_color=WHITE, end_color=WHITE, fill_type="solid")
                else:
                    cell.fill = PatternFill(start_color=SECONDARY_COLOR, end_color=SECONDARY_COLOR, fill_type="solid")
                
                # Format numeric cells with conditional formatting
                if col_num in [5, 6, 7] and value not in ["N/A", None]:
                    cell.number_format = '0.00'
                    
                    # Apply color coding based on thresholds
                    if isinstance(value, (int, float)):
                        if value > 80:
                            cell.font = Font(color="C00000", bold=True)  # Dark Red
                            cell.fill = PatternFill(start_color="FFEBE6", end_color="FFEBE6", fill_type="solid")
                        elif value > 60:
                            cell.font = Font(color="FF6B35", bold=True)  # Orange
                            cell.fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
                        elif value < 20:
                            cell.font = Font(color="00B050", bold=True)  # Green
                
                # Color code state column
                if col_num == 3:
                    if value == "running":
                        cell.font = Font(color="00B050", bold=True)  # Green
                    elif value == "stopped":
                        cell.font = Font(color="C00000", bold=True)  # Red
                    elif value == "terminated":
                        cell.font = Font(color="808080", italic=True)  # Gray
            
            row_num += 1
        
        # Add summary row
        summary_row = row_num + 1
        ws.cell(row=summary_row, column=1, value="Summary:").font = Font(bold=True)
        ws.cell(row=summary_row, column=2, value=f"Total Instances: {len(ec2)}")
        ws.cell(row=summary_row, column=3, value=f"Running: {len([i for i in ec2 if i.get('state') == 'running'])}")
        ws.cell(row=summary_row, column=4, value=f"Stopped: {len([i for i in ec2 if i.get('state') == 'stopped'])}")
        
        # Add auto filter
        ws.auto_filter.ref = f"A5:{get_column_letter(len(headers))}{row_num}"
        
        # Freeze header row
        ws.freeze_panes = "A6"
        
        # ============== RDS Sheet ==============
        ws2 = wb.create_sheet("RDS Metrics")
        
        # Add report title
        ws2.merge_cells('A1:G1')
        title_cell = ws2.cell(row=1, column=1, value="RDS Utilization Report")
        title_cell.font = title_font
        title_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Add subtitle with date
        ws2.merge_cells('A2:G2')
        subtitle_cell = ws2.cell(row=2, column=1, value=f"Report Date: {self.today}")
        subtitle_cell.font = Font(size=11, color="808080")
        subtitle_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Add data source info
        ws2.merge_cells('A3:G3')
        source_cell = ws2.cell(row=3, column=1, value=f"Data Source: CloudWatch (Last {DAYS_RANGE} days)")
        source_cell.font = Font(size=9, italic=True, color="808080")
        source_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Leave one empty row
        ws2.row_dimensions[4].height = 5
        
        # RDS Headers
        rds_headers = [
            "DB Identifier", "Status", "Avg CPU (%)", 
            "Avg Freeable Memory (MB)", "Avg Connections", 
            "Avg Read IOPS", "Avg Write IOPS"
        ]
        
        # Add headers
        for col_num, header in enumerate(rds_headers, 1):
            cell = ws2.cell(row=5, column=col_num, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = thin_border
        
        # Set column widths
        rds_column_widths = [22, 12, 12, 18, 15, 12, 13]
        for i, width in enumerate(rds_column_widths, 1):
            ws2.column_dimensions[get_column_letter(i)].width = width
        
        # Add RDS data
        row_num = 6
        for db in rds:
            db_name = db.get("db_identifier") or db.get("DB")
            dims = [{"Name": "DBInstanceIdentifier", "Value": db_name}]
            
            if db["status"] != "available":
                row_data = [
                    db_name, db["status"], "N/A", "N/A", "N/A", "N/A", "N/A"
                ]
            else:
                row_data = [
                    db_name,
                    db["status"],
                    self.avg_metric("AWS/RDS", "CPUUtilization", dims),
                    self.avg_metric("AWS/RDS", "FreeableMemory", dims),
                    self.avg_metric("AWS/RDS", "DatabaseConnections", dims),
                    self.avg_metric("AWS/RDS", "ReadIOPS", dims),
                    self.avg_metric("AWS/RDS", "WriteIOPS", dims)
                ]
            
            # Add row data
            for col_num, value in enumerate(row_data, 1):
                cell = ws2.cell(row=row_num, column=col_num, value=value)
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="center", vertical="center")
                
                # Apply alternating row colors
                if row_num % 2 == 0:
                    cell.fill = PatternFill(start_color=WHITE, end_color=WHITE, fill_type="solid")
                else:
                    cell.fill = PatternFill(start_color=SECONDARY_COLOR, end_color=SECONDARY_COLOR, fill_type="solid")
                
                # Format numeric cells
                if col_num in [3, 4, 5, 6, 7] and value not in ["N/A", None]:
                    if col_num == 4:  # Freeable Memory (MB)
                        cell.number_format = '#,##0'
                    else:
                        cell.number_format = '0.00'
                    
                    # Highlight high CPU
                    if col_num == 3 and isinstance(value, (int, float)) and value > 80:
                        cell.font = Font(color="C00000", bold=True)
                        cell.fill = PatternFill(start_color="FFEBE6", end_color="FFEBE6", fill_type="solid")
                
                # Color code status column
                if col_num == 2:
                    if value == "available":
                        cell.font = Font(color="00B050", bold=True)
                    elif value == "stopped":
                        cell.font = Font(color="C00000", bold=True)
                    elif value in ["stopping", "starting"]:
                        cell.font = Font(color="FF6B35", bold=True)
            
            row_num += 1
        
        # Add summary row
        summary_row = row_num + 1
        ws2.cell(row=summary_row, column=1, value="Summary:").font = Font(bold=True)
        ws2.cell(row=summary_row, column=2, value=f"Total DBs: {len(rds)}")
        ws2.cell(row=summary_row, column=3, value=f"Available: {len([db for db in rds if db.get('status') == 'available'])}")
        
        # Add auto filter
        ws2.auto_filter.ref = f"A5:{get_column_letter(len(rds_headers))}{row_num}"
        
        # Freeze header row
        ws2.freeze_panes = "A6"
        
        # Add info sheet
        ws3 = wb.create_sheet("Report Info")
        
        # Add report information
        ws3.column_dimensions['A'].width = 25
        ws3.column_dimensions['B'].width = 40
        
        info_data = [
            ["Report Name", "AWS Resource Utilization Report"],
            ["Report Date", self.today],
            ["Report Period", f"Last {DAYS_RANGE} days"],
            ["Generated By", "AWS Monitoring Automation"],
            ["Contact", "monitoring@acc.ltd"],
            ["Confidentiality", "Internal Use Only"],
            ["", ""],
            ["Color Codes:", ""],
            ["", "Green: Good (< 20%)"],
            ["", "Orange: Warning (60-80%)"],
            ["", "Red: Critical (> 80%)"],
            ["", ""],
            ["Metric Legend:", ""],
            ["", "CPU: Average CPU utilization"],
            ["", "Memory: Average memory usage %"],
            ["", "Disk: Average disk usage %"],
            ["", "IOPS: Input/Output Operations per second"]
        ]
        
        for idx, row_data in enumerate(info_data, start=1):
            cell1 = ws3.cell(row=idx, column=1, value=row_data[0])
            cell2 = ws3.cell(row=idx, column=2, value=row_data[1])
            
            if idx <= 6:
                cell1.font = Font(bold=True, color=PRIMARY_COLOR)
            elif idx == 8 or idx == 13:
                cell1.font = Font(bold=True)
        
        # Save workbook
        path = f"{TMP_DIR}/aws_metrics_{self.today}.xlsx"
        wb.save(path)
        return path


def lambda_handler(event, context):
    gen = AWSReportGenerator()
    gen.create_daily_folders()

    # Fetch inventories from S3 output folder
    ec2 = gen.get_ec2_instances()
    rds = gen.get_rds_instances()

    # Generate reports
    word_path = gen.generate_word(ec2, rds)
    excel_path = gen.generate_excel(ec2, rds)

    # Upload reports to S3
    results = {}
    for f in [word_path, excel_path]:
        key = f"reports/{gen.today}/{os.path.basename(f)}"
        with open(f, "rb") as fd:
            s3_client.put_object(Bucket=BUCKET_NAME, Key=key, Body=fd.read())
        results[os.path.basename(f)] = f"s3://{BUCKET_NAME}/{key}"

    return {
        "statusCode": 200,
        "body": json.dumps(results)
    }