import boto3
import time
import random
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Tuple

# =============================
# AWS Clients
# =============================
cloudwatch = boto3.client("cloudwatch")
ec2 = boto3.client("ec2")

# IST timezone
IST = timezone(timedelta(hours=5, minutes=30))

# =============================
# Retry Wrapper
# =============================
def cw_call_with_retry(func, retries=3, base_delay=1):
    for attempt in range(retries):
        try:
            return func()
        except Exception:
            if attempt == retries - 1:
                raise
            time.sleep((base_delay * (2 ** attempt)) + random.random())

# =============================
# Detect OS (EC2 only, chunk-safe)
# =============================
def get_ec2_os_map(instance_ids: List[str]) -> Dict[str, bool]:
    os_map = {}
    if not instance_ids:
        return os_map

    # EC2 DescribeInstances allows max 100 IDs per call
    for i in range(0, len(instance_ids), 100):
        chunk = instance_ids[i:i + 100]
        resp = ec2.describe_instances(InstanceIds=chunk)

        for reservation in resp.get("Reservations", []):
            for inst in reservation.get("Instances", []):
                os_map[inst["InstanceId"]] = (
                    inst.get("Platform", "").lower() == "windows"
                )

    return os_map

# =============================
# Fetch single CloudWatch metric
# =============================
def get_metric_for_window(namespace: str, metric_name: str, dimensions: list,
                          start_time: datetime, end_time: datetime, unit: str | None = None) -> dict:
    params = {
        "Namespace": namespace,
        "MetricName": metric_name,
        "Dimensions": dimensions,
        "StartTime": start_time,
        "EndTime": end_time,
        "Period": 86400,
        "Statistics": ["Average", "Minimum", "Maximum"]
    }

    if unit:
        params["Unit"] = unit

    try:
        resp = cw_call_with_retry(lambda: cloudwatch.get_metric_statistics(**params))
        datapoints = resp.get("Datapoints", [])

        if not datapoints:
            return {"Average": "N/A", "Minimum": "N/A", "Maximum": "N/A"}

        latest = max(datapoints, key=lambda x: x["Timestamp"])
        return {
            "Average": round(latest.get("Average", 0), 2),
            "Minimum": round(latest.get("Minimum", 0), 2),
            "Maximum": round(latest.get("Maximum", 0), 2)
        }

    except Exception as e:
        print(f"[CW ERROR] {metric_name} {dimensions}: {e}")
        return {"Average": "N/A", "Minimum": "N/A", "Maximum": "N/A"}

# =============================
# Parallel Metrics Collection
# =============================
def fetch_metrics_parallel(instances: List[dict], windows: List[Tuple[datetime, datetime, str]]) -> dict:
    results = {}

    ec2_ids = [
        i["Id"] for i in instances
        if isinstance(i, dict) and i.get("Type") == "EC2" and i.get("Id")
    ]

    os_map = get_ec2_os_map(ec2_ids)

    def fetch_instance_metrics(instance):
        instance_id = instance.get("Id")
        instance_type = instance.get("Type")
        state = instance.get("State")

        # -------- Skip inactive --------
        if instance_type == "EC2" and state != "running":
            return instance_id, {"state": state, "metrics": "N/A"}

        if instance_type == "RDS" and state != "available":
            return instance_id, {"state": state, "metrics": "N/A"}

        is_windows = os_map.get(instance_id, False)

        dimensions = [{
            "Name": "InstanceId" if instance_type == "EC2" else "DBInstanceIdentifier",
            "Value": instance_id
        }]

        instance_metrics = {}

        for start, end, label in windows:
            day_metrics = {}

            # CPU
            day_metrics["cpu"] = get_metric_for_window(
                "AWS/EC2" if instance_type == "EC2" else "AWS/RDS",
                "CPUUtilization",
                dimensions,
                start,
                end,
                unit="Percent"
            )

            # Memory
            if instance_type == "EC2":
                if is_windows:
                    mem_namespace = "Windows/Default"
                    mem_metric = "MemoryUtilisation"
                else:
                    mem_namespace = "CWAgent"
                    mem_metric = "mem_used_percent"
                mem_unit = "Percent"
            else:
                mem_namespace = "AWS/RDS"
                mem_metric = "FreeableMemory"
                mem_unit = "Bytes"

            day_metrics["memory"] = get_metric_for_window(
                mem_namespace,
                mem_metric,
                dimensions,
                start,
                end,
                unit=mem_unit
            )

            # Disk (EC2 only)
            if instance_type == "EC2":
                if is_windows:
                    disk_metric = "LogicalDisk % Free Space"
                    disk_dimensions = dimensions
                else:
                    disk_metric = "disk_used_percent"
                    disk_dimensions = dimensions + [{"Name": "path", "Value": "/"}]

                day_metrics["disk"] = get_metric_for_window(
                    "CWAgent",
                    disk_metric,
                    disk_dimensions,
                    start,
                    end,
                    unit="Percent"
                )

            # RDS extras
            if instance_type == "RDS":
                for metric in ("DatabaseConnections", "ReadIOPS", "WriteIOPS"):
                    day_metrics[metric] = get_metric_for_window(
                        "AWS/RDS",
                        metric,
                        dimensions,
                        start,
                        end
                    )

            instance_metrics[label] = day_metrics

        return instance_id, instance_metrics

    max_workers = min(8, max(1, len(instances)))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(fetch_instance_metrics, inst) for inst in instances]
        for future in as_completed(futures):
            instance_id, data = future.result()
            if instance_id:
                results[instance_id] = data

    return results

# =============================
# 🔥 LAMBDA HANDLER
# =============================
def lambda_handler(event, context):
    if not isinstance(event, list):
        return {"metrics": {}}

    valid_instances = [i for i in event if isinstance(i, dict) and i.get("Id")]
    if not valid_instances:
        return {"metrics": {}}

    days = 1
    end_time = datetime.now(IST)
    start_time = end_time - timedelta(days=days)

    windows = [(start_time, end_time, f"last_{days}_days")]

    metrics = fetch_metrics_parallel(valid_instances, windows)
    return {"metrics": metrics}
