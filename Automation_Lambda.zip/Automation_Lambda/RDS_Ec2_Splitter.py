import boto3
import json
from datetime import datetime, timezone, timedelta

s3_client = boto3.client("s3")

BUCKET_NAME = "aws-utilization-reports-prod1"
OUTPUT_PREFIX = "output/"

# IST timezone
IST = timezone(timedelta(hours=5, minutes=30))


def get_latest_date_prefix():
    """
    Finds the latest YYYY-MM-DD folder under output/
    Example: output/2026-01-25/
    """

    prefixes = []
    continuation_token = None

    while True:
        kwargs = {
            "Bucket": BUCKET_NAME,
            "Prefix": OUTPUT_PREFIX,
            "Delimiter": "/"
        }
        if continuation_token:
            kwargs["ContinuationToken"] = continuation_token

        resp = s3_client.list_objects_v2(**kwargs)

        for p in resp.get("CommonPrefixes", []):
            prefixes.append(p["Prefix"])

        if resp.get("IsTruncated"):
            continuation_token = resp.get("NextContinuationToken")
        else:
            break

    if not prefixes:
        raise Exception("No date folders found under output/")

    dated_prefixes = []
    for p in prefixes:
        date_str = p.replace(OUTPUT_PREFIX, "").strip("/")
        try:
            dated_prefixes.append((datetime.strptime(date_str, "%Y-%m-%d"), p))
        except ValueError:
            continue

    if not dated_prefixes:
        raise Exception("No valid YYYY-MM-DD folders found")

    # Latest date folder
    return sorted(dated_prefixes, reverse=True)[0][1]


def lambda_handler(event, context):
    latest_prefix = get_latest_date_prefix()

    ec2_key = f"{latest_prefix}ec2_inventory.json"
    rds_key = f"{latest_prefix}rds_inventory.json"

    # ---------- Load inventories ----------
    try:
        ec2_obj = s3_client.get_object(Bucket=BUCKET_NAME, Key=ec2_key)
        rds_obj = s3_client.get_object(Bucket=BUCKET_NAME, Key=rds_key)
    except Exception as e:
        raise Exception(f"Inventory files not found in {latest_prefix}: {str(e)}")

    ec2_data = json.loads(ec2_obj["Body"].read())
    rds_data = json.loads(rds_obj["Body"].read())

    items = []

    # ---------- EC2 ----------
    for inst in ec2_data.get("ec2_instances", []):
        state = inst.get("state")
        if state in ("running", "stopped"):
            items.append({
                "Id": inst.get("instance_id"),
                "Type": "EC2",
                "Name": inst.get("name", ""),
                "Platform": inst.get("platform", "linux"),
                "State": state
            })

    # ---------- RDS ----------
    for db in rds_data.get("rds_instances", []):
        status = db.get("status")
        if status in ("available", "stopped"):
            items.append({
                "Id": db.get("db_identifier"),
                "Type": "RDS",
                "Engine": db.get("engine"),
                "Platform": "rds",
                "State": status
            })

    # Step Functions Map state expects a PURE ARRAY
    return items
