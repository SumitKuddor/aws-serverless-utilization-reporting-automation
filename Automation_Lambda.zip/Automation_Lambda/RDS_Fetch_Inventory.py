import boto3
import json
from datetime import datetime, timezone, timedelta

# AWS Clients
rds_client = boto3.client("rds")
s3_client = boto3.client("s3")

BUCKET_NAME = "aws-utilization-reports-prod1"

# IST Timezone
IST = timezone(timedelta(hours=5, minutes=30))

def lambda_handler(event, context):
    # Today's date in IST
    today = datetime.now(IST).strftime("%Y-%m-%d")
    RDS_FILE_KEY = f"output/{today}/rds_inventory.json"

    paginator = rds_client.get_paginator("describe_db_instances")
    dbs = []

    for page in paginator.paginate():
        for db in page.get("DBInstances", []):

            dbs.append({
                "db_identifier": db.get("DBInstanceIdentifier", ""),
                "engine": db.get("Engine", ""),
                "engine_version": db.get("EngineVersion", ""),
                "instance_class": db.get("DBInstanceClass", ""),
                "allocated_storage_gb": db.get("AllocatedStorage"),
                "storage_type": db.get("StorageType", ""),
                "multi_az": db.get("MultiAZ", False),
                "availability_zone": db.get("AvailabilityZone", ""),
                "publicly_accessible": db.get("PubliclyAccessible", False),
                "status": db.get("DBInstanceStatus", "")
            })

    data = {
        "total_rds": len(dbs),
        "rds_instances": dbs,
        "generated_at": datetime.now(IST).isoformat(),
        "timezone": "IST"
    }

    # Upload to S3
    s3_client.put_object(
        Bucket=BUCKET_NAME,
        Key=RDS_FILE_KEY,
        Body=json.dumps(data, indent=2),
        ContentType="application/json"
    )

    return {
        "status": "success",
        "s3_path": f"s3://{BUCKET_NAME}/{RDS_FILE_KEY}",
        "total_rds": len(dbs)
    }
